// Modal Resizer
function modalResizer(imageFile) {
    if (imageFile === "") {
        console.log("No Selected Image");
        return;
    }
    const modal = document.getElementById("modalResizer");
    const modalImage = document.getElementById("modalImage");
    const modalValueUrlImage = document.getElementById("filenameGallery");
    const localImagePath = imageFile;
    modalValueUrlImage.value = localImagePath;
    modalImage.src = "/images/" + imageFile;
    modal.style.display = "flex";
}

function closeModal() {
    const modal = document.getElementById("modalResizer");
    modal.style.display = "none";
    const downloadButton = document.getElementById('downloadButton');
    const redirectButton = document.getElementById('redirectButton');
    if (downloadButton) downloadButton.remove();
    if (redirectButton) redirectButton.remove();
}