
// Main App Resizer
document.getElementById("uploadForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(event.target);
  const format = formData.get("format");
  const response = await fetch("/upload", {
    method: "POST",
    body: formData,
  });

  if (response.status === 200) {
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);

    let downloadButton = document.getElementById("downloadButton");
    if (!downloadButton) {
      downloadButton = document.createElement("a");
      downloadButton.id = "downloadButton";
      downloadButton.textContent = "Download";
      downloadButton.classList.add("btn", "btn-success", "w-100");
      document.getElementById("error").appendChild(downloadButton);
    }
    downloadButton.href = url;
    const date = Date.now();
    downloadButton.download = `resized_${date}.${format}`;

    let redirectButton = document.getElementById("redirectButton");
    if (!redirectButton) {
      redirectButton = document.createElement("button");
      redirectButton.id = "redirectButton";
      redirectButton.textContent = "View";
      redirectButton.classList.add("btn", "btn-success", "w-100", "margin-top");
      document.getElementById("error").appendChild(redirectButton);
    }
    redirectButton.addEventListener("click", () => {
      window.open(url, "_blank");
    });

    fetchImages();
  } else {
    document.getElementById("error").innerHTML = "<div class='alert alert-danger'>Error Uploading Image. Allowed: JPG, JPEG, PNG, AVIF.</div>";
  }
});

fetchImages();