//Reset Fields
const uploadFormFields = document.getElementById("uploadForm");
uploadFormFields.addEventListener("submit", function (event) {
    event.preventDefault();
    uploadFormFields.reset();
});

const uploadFormFieldsGallery = document.getElementById("resizeForm");
uploadFormFieldsGallery.addEventListener("submit", function (event) {
    event.preventDefault();
    uploadFormFieldsGallery.reset();
});