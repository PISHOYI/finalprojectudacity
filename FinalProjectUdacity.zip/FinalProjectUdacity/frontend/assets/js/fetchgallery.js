//Fetch Image Gallery And Download Resized Image
async function fetchImages() {
    const response = await fetch("/images");
    const images = await response.json();
    const gallery = document.getElementById("gallery");
    gallery.innerHTML = "";
    images.forEach((image) => {
      const img = document.createElement("img");
      img.src = `/images/${image}`;
      img.alt = image;
      img.style.width = "250px";
      img.style.height = "250px";
      img.id = image;
      img.classList = "imgGallery";
      img.addEventListener("click", () => modalResizer(image));
      gallery.appendChild(img);
    });
  }