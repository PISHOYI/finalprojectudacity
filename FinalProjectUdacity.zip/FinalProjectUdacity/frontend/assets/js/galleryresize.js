// Gallery Resizer
document.getElementById('resizeForm').addEventListener('submit', async (event) => {
  event.preventDefault();

  const filename = document.getElementById('filenameGallery').value;
  const width = parseInt(document.getElementById('widthGallery').value, 10);
  const height = parseInt(document.getElementById('heightGallery').value, 10);

  try {
    const response = await fetch('/resize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename, width, height }),
    });

    if (response.ok) {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);

      let downloadButton = document.getElementById('downloadButton');
      if (!downloadButton) {
        downloadButton = document.createElement('a');
        downloadButton.id = 'downloadButton';
        downloadButton.textContent = 'Download';
        downloadButton.classList.add('btn', 'btn-success', 'w-100');
        document.getElementById('errorGallery').appendChild(downloadButton);
      }
      downloadButton.href = url;
      downloadButton.download = `resized_${filename}`;

      let redirectButton = document.getElementById('redirectButton');
      if (!redirectButton) {
        redirectButton = document.createElement('button');
        redirectButton.id = 'redirectButton';
        redirectButton.textContent = 'View';
        redirectButton.classList.add('btn', 'btn-success', 'w-100', 'margin-top');
        document.getElementById('errorGallery').appendChild(redirectButton);
      }
      redirectButton.addEventListener('click', () => {
        window.location.href = url;
      });

      const modal = document.getElementById('modalResizer');
      modal.style.display = 'flex';
    } else {
      console.error('Error resizing image:', response.statusText);
    }
  } catch (error) {
    console.error('Error:', error);
  }
});
