//Resize Images
import express from 'express';
import path from 'path';
import sharp from 'sharp';
import fs from 'fs';

const router = express.Router();

router.post('/', async (req, res) => {
  const { filename, width, height } = req.body;
  const inputImagePath = path.join(__dirname, '../../images', filename);

  if (!fs.existsSync(inputImagePath)) {
    console.error(`Image file not found: ${inputImagePath}`);
    return res.status(404).json({ error: 'Image Not Found' });
  }

  try {
    const resizedImageBuffer = await sharp(inputImagePath)
      .resize(parseInt(width), parseInt(height), { fit: 'inside' })
      .toBuffer();

    res.set('Content-Disposition', `attachment; filename=resized_${filename}`);
    res.type('image/jpeg');
    res.status(200).send(resizedImageBuffer);
  } catch (error) {
    console.error('Error resizing image:', error);
    res.status(500).json({ error: 'Error resizing image' });
  }
});

export default router;
