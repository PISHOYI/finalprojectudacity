//Resize Selected Images Gallery
import express from 'express';
import path from 'path';
import fs from 'fs';

const router = express.Router();

router.get('/', (req, res) => {
  const imagesDir = path.join(__dirname, '../../images_resized');
  fs.readdir(imagesDir, (err, files) => {
    if (err) {
      console.error('Unable to scan directory', err);
      return res.status(500).send('Unable to scan directory');
    }
    const imageFiles = files.filter((file) =>
      /\.(jpg|jpeg|png|avif)$/.test(file),
    );
    res.json(imageFiles);
  });
});

export default router;
