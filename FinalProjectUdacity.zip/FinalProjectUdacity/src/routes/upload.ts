//Upload App
import express from 'express';
import path from 'path';
import multer from 'multer';

const router = express.Router();
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../../images'));
  },
  filename: (req, file, cb) => {
    const time = Date.now();
    const fileName = `${time}${path.extname(file.originalname)}`;
    const extension = path.extname(file.originalname).toLowerCase();
    if (['.jpg', '.jpeg', '.png', '.avif'].includes(extension)) {
      cb(null, fileName);
    }
  },
});

const upload = multer({ storage });

router.post('/', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }
  res.status(200).send('File uploaded successfully.');
});

export default router;
