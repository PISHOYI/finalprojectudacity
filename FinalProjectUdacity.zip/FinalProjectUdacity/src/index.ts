//Main App Typescript
import express from 'express';
import path from 'path';
import fs from 'fs';
import imagesRouter from './routes/images';
import imagesResizedRouter from './routes/images_resized';
import resizeRouter from './routes/resize';
import multer from 'multer';
import sharp from 'sharp';

const app = express();
const port = 3000;

// Check Directions
const imagesDir = path.resolve(__dirname, '../images');
const resizedImagesDir = path.resolve(__dirname, '../images_resized');

if (!fs.existsSync(imagesDir)) {
  fs.mkdirSync(imagesDir, { recursive: true });
}
if (!fs.existsSync(resizedImagesDir)) {
  fs.mkdirSync(resizedImagesDir, { recursive: true });
}

// Serve Static Files For FrontEnd
app.use(express.static(path.join(__dirname, '../frontend')));
app.use(express.static(path.join(__dirname, '../frontend/assets/css')));
app.use(express.static(path.join(__dirname, '../frontend/assets/js')));
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Endpoints
app.use('/images', imagesRouter);
app.use('/images_resized', imagesResizedRouter);
app.use('/resize', resizeRouter);

// Serve static
app.use('/images', express.static(imagesDir));
app.use('/images_resized', express.static(resizedImagesDir));

// Multer Configuration
let uploadedFileName: string;
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, imagesDir);
  },
  filename: (req, file, cb) => {
    const time = Date.now();
    const fileName = `${time}${path.extname(file.originalname)}`;
    const extension = path.extname(file.originalname).toLowerCase();
    if (['.jpg', '.jpeg', '.png', '.avif'].includes(extension)) {
      uploadedFileName = fileName;
      cb(null, fileName);
    } else {
      cb(new Error('Invalid file type'), '');
    }
  },
});

// Sharp Configuration

const upload = multer({ storage });

app.post('/upload', upload.single('file'), async (req, res) => {
  const width = parseInt(req.body.width, 10);
  const height = parseInt(req.body.height, 10);

  if (isNaN(width) || isNaN(height) || width <= 0 || height <= 0) {
    return res.status(400).send('Width and Height Must Be Valid Numbers');
  }

  if (!req.file) {
    return res.status(400).send('No File Uploaded.');
  }

  const sourceImagePath = path.join(imagesDir, uploadedFileName);
  const targetImagePath = path.join(
    resizedImagesDir,
    `resized_${Date.now()}${path.extname(uploadedFileName)}`,
  );

  try {
    await sharp(sourceImagePath).resize(width, height).toFile(targetImagePath);
    console.log('Image Resized Successfully!');
    res.status(200).sendFile(targetImagePath);
  } catch (err) {
    console.error('Error resizing image:', err);
    res.status(500).send('Error resizing image.');
  }
});

// Run Server
app.listen(port, () => {
  console.log(`Server Running at localhost:${port}`);
});

// Export Express App For Testing
export default app;
