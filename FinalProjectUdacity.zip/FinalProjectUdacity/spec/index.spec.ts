//Unit Test With Jasmine
import request from 'supertest';
import app from '../src/index';
import path from 'path';
import fs from 'fs';

describe('Image Processing Web App Unit Testing', () => {
    // Set Testing Env
    const testImagePath = path.join(__dirname, 'test_images', 'test1.jpg');

    beforeAll(() => {
        console.log('Checking If Test Image Exists at:', testImagePath);
        if (!fs.existsSync(testImagePath)) {
            throw new Error('Error: Test Image Not Found');
        }
    });

    // Test Image Processing From Upload to Resize
    it('Should Upload & Resize an Image', async () => {
        const response = await request(app)
            .post('/upload')
            .field('width', '250')
            .field('height', '250')
            .attach('file', testImagePath);

        expect(response.status).toBe(200);
        console.log("Success! Image Saved & Resized");
        expect(response.body).toBeDefined();
    });

    // Test For Invaild Width & Height
    it('Should Return an Error For Invalid Width & Height', async () => {
        const response = await request(app)
            .post('/upload')
            .field('width', 'invalid')
            .field('height', 'invalid');

            
            expect(response.status).toBe(400);
            expect(response.text).toContain('Width and Height Must Be Valid Numbers');
            console.log("Success! Validation Test");
    });

    // Test For Listing Original Images
    it('Should List Original Images', async () => {
        const response = await request(app).get('/images');

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
        console.log("Success! Listed Original Images");
    });

    // Test For Listing Resized Images
    it('Should List Resized Images', async () => {
        const response = await request(app).get('/images_resized');

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
        console.log("Success! Listed Resized Images");
    });

    //Test No File Uploaded
    it('Should Return an Error If No File Uploaded', async () => {
        const response = await request(app)
            .post('/upload')
            .field('width', '200')
            .field('height', '200');

        expect(response.status).toBe(400);
        expect(response.text).toContain('No File Uploaded.');
        console.log("Success! No File Uploaded");

    });


    // Test Resizing A NON-EXISTING Image
    it('Should Return an Error for Resizing a NON-EXISTING Image', async () => {
        const response = await request(app)
            .post('/resize')
            .send({ filename: 'non_existing.jpg', width: 100, height: 100 });

        expect(response.status).toBe(404);
        expect(response.body.error).toBe('Image Not Found');
        console.log("Success! Error With Resizing Non-Existing Image");
    });
});
